import 'package:flutter/material.dart';
import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:splash_screen_view/SplashScreenView.dart';

void main() {
  runApp(MyApp());

}



class MyApp extends StatelessWidget {
  
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
        theme: ThemeData(
          primarySwatch: Colors.blue,
          visualDensity: VisualDensity.adaptivePlatformDensity,
        ),
        home: SplashScreenView(
          home: Home(),
          duration: 5000,
          imageSize: 130,
          imageSrc: "assets/splash.png",
          backgroundColor: Colors.white,
        ));
  }
}

class Home extends StatefulWidget {
  
  @override
  _HomeState createState() => _HomeState();
  
}

class _HomeState extends State<Home> {
  
  void initState() {
    requestPermission();
    super.initState();
  }
  Future requestPermission() async {
    
  if (PermissionStatus.denied != null) {
    Map<Permission, PermissionStatus> status = await [
    Permission.locationAlways,
    Permission.photos,
    Permission.camera,
  ].request();
  } else if(PermissionStatus.permanentlyDenied != null){
    Map<Permission, PermissionStatus> status = await [
      Permission.locationAlways,
      Permission.photos,
      Permission.camera,
    ].request();
  }else if (PermissionStatus.undetermined != null){
    Map<Permission, PermissionStatus> status = await [
      Permission.locationAlways,
      Permission.photos,
      Permission.camera,
    ].request();
  }else if(PermissionStatus.restricted != null) {
    Map<Permission, PermissionStatus> status = await [
      Permission.locationAlways,
      Permission.photos,
      Permission.camera,
    ].request();
  }

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: WebviewScaffold(
          url: 'http://sunwaso.com/mobile/',
        ),
      ),
    );
  }
}
